expenses = []
days = int(input("Enter number of days: "))

for i in range(days):
    amount = float(input(f"Enter expense for day {i+1}: "))
    expenses.append(amount)

total = sum(expenses)
average = total / days
highest = max(expenses)

print("\n--- Expense Report ---")
print("Total Expense:", total)
print("Average Expense:", average)
print("Highest Expense:", highest)
