
days = int(input("Enter the number of days to process: "))  
temperatures = []  
total_temp = 0.0   


for i in range(1, days + 1):
    
    temp = float(input(f"Day {i} - Enter temperature: "))
    temperatures.append(temp)
    
 
    total_temp += temp 


if days > 0:
    average = total_temp / days 
    
   
    if average >= 30:
        status = "Hot"
    elif average >= 15:
        status = "Moderate"
    else:
        status = "Cold"
        
    print(f"\nAverage Temperature: {average:.2f}°C")
    print(f"Climate Classification: {status}")
else:
    print("No data was entered to process.")
