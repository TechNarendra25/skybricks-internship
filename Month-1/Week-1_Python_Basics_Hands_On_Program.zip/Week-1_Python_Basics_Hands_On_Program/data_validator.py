name = input("Enter your name: ")
age = int(input("Enter your age: "))

if len(name) < 3:
    print("Invalid Name: Too Short")
elif age < 18:
    print("Access Denied: Age must be 18 or above")
else:
    print("Data Validated Successfully")
