temperatures = []

for i in range(7):
    temp = float(input(f"Enter temperature for day {i+1}: "))
    temperatures.append(temp)

print("\nAverage Temperature:", sum(temperatures)/7)

for i in range(1, 7):
    if temperatures[i] > temperatures[i-1]:
        print(f"Day {i+1}: Temperature Increased")
    elif temperatures[i] < temperatures[i-1]:
        print(f"Day {i+1}: Temperature Decreased")
    else:
        print(f"Day {i+1}: Temperature Same")
