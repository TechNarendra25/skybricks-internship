total_classes = int(input("Enter total number of classes: "))
attended = int(input("Enter attended classes: "))

attendance_percentage = (attended / total_classes) * 100

print("Attendance Percentage:", attendance_percentage)

if attendance_percentage >= 75:
    print("Status: Eligible for Exam")
else:
    print("Status: Not Eligible for Exam")
